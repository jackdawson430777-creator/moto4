pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories {
        google()
        mavenCentral()
        // Xposed API 82 is not hosted on Google Maven or Maven Central.
        maven { url = uri("https://artifactory.appodeal.com/appodeal-public/") }
        // Public Xposed repository fallback.
        maven { url = uri("https://api.xposed.info/") }
    } }
rootProject.name = "MotoPixelFolderLSPosed"
include(":app")
