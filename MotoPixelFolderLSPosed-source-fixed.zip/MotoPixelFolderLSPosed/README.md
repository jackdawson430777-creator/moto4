# Moto Pixel Folder LSPosed (experimental scaffold)

Target APK inspected: Motorola Launcher (`com.motorola.launcher3`), with resources such as
`folder_content_fullscreen`, `folder_title_fullscreen`, and `folder_application_fullscreen`.

## What this is
A buildable starting-point LSPosed module scaffold. It attempts to hook Launcher3 folder
views and applies a rounded dark surface as a safe first experiment.

## Important limitation
This is **not yet a complete Pixel-style folder conversion**. The uploaded APK's resource
names establish that fullscreen-folder UI exists, but do not establish the exact runtime
view hierarchy, layout owner, or animation implementation. Forcing a popup size before
those are verified could break folder opening, rotation, gestures, or app launching.

## Build
Use JDK 17 and Android SDK 35, then run:

```bash
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`

## Install / test
1. Install the APK and enable it in LSPosed.
2. Scope the module to `com.motorola.launcher3` only.
3. Reboot or restart the launcher.
4. Test opening/closing folders, launching apps, renaming folders, portrait/landscape, and dark/light mode.
5. Disable the module if the launcher crashes.

## Next step for a reliable popup
Capture the actual folder view hierarchy and identify the folder container/window sizing path in this
exact launcher version. Then implement width/height, center positioning, dim layer, grid spacing,
and open/close transitions together. The Pixel Launcher implementation itself is not included.
